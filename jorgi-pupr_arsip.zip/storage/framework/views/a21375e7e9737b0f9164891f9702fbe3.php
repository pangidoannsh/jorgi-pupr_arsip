<?php
    use Carbon\Carbon;
?>


<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="mt-3 mb-2">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <a href="<?php echo e(route('unit.create')); ?>" class="btn btn-primary" style="width: max-content">
                    <i class="bi bi-plus"></i> Unit Kerja
                </a>
            </div>
            <!-- Table with hoverable rows -->
            <table class="table table-hover table-stripped" id="dataTable">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
            </table>
            <!-- End Table with hoverable rows -->

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            const table = $("#dataTable").DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('unit.data')); ?>",
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'nama',
                        name: 'Nama',
                        orderable: false,

                    },
                    {
                        data: 'action',
                        name: 'Aksi',
                        orderable: false,
                        searchable: false
                    },
                ],
                columnDefs: [{
                    targets: 0,
                    className: "text-center",
                    width: "120px"
                }]
            })
        })
    </script>
    <script>
        $(document).on("submit", ".formDelete", function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Unit kerja ini akan dihapus secara permanen!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    e.currentTarget.submit()
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/unit/index.blade.php ENDPATH**/ ?>