<a href="<?php echo e($item->link); ?>" target="_blank"><?php echo e($item->name); ?></a>
<?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/partials/link.blade.php ENDPATH**/ ?>