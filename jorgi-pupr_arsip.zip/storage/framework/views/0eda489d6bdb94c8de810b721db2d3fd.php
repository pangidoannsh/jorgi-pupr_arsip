
<?php
    $userRole = Auth::user()->role;
?>
<?php $__env->startPush('title-prefix'); ?>
    <a href="<?php echo e(route('usulan.index')); ?>" class="btn btn-primary mb-3" style="width: max-content">Kembali</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-6">
            <form action="<?php echo e(route('suratCuti.store')); ?>" method="POST" class="d-flex flex-column card p-4" style="gap:12px"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- User yang mengajukan -->
                <div class="form-group">
                    <label for="user_id">Nama Pegawai yang Mengajukan<span class="text-danger">*</span></label>
                    <?php if($userRole === 'user'): ?>
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
                    <?php endif; ?>
                    <select class="form-select <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="user_id" id="user_id"
                        required <?php echo e($userRole == 'user' ? 'disabled' : ''); ?>>
                        <?php if($userRole == 'admin'): ?>
                            <option selected disabled>Pilih Pegawai</option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($userRole === 'user'): ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(Auth::user()->id == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php else: ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- User yang membuat -->
                <input type="hidden" name="user_created" value="<?php echo e(Auth::id()); ?>">

                <!-- Jenis Cuti -->
                <div class="form-group">
                    <label for="jenis_cuti">Jenis Cuti<span class="text-danger">*</span></label>
                    <select class="form-select <?php $__errorArgs = ['jenis_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jenis_cuti" id="jenis_cuti"
                        required>
                        <option selected disabled>Pilih Jenis Cuti</option>
                        <option value="tahunan" <?php echo e(old('jenis_cuti') == 'tahunan' ? 'selected' : ''); ?>>Cuti Tahunan
                        </option>
                        <option value="sakit" <?php echo e(old('jenis_cuti') == 'sakit' ? 'selected' : ''); ?>>Cuti Sakit</option>
                        <option value="melahirkan" <?php echo e(old('jenis_cuti') == 'melahirkan' ? 'selected' : ''); ?>>Cuti
                            Melahirkan
                        </option>
                        <option value="alasan_penting" <?php echo e(old('jenis_cuti') == 'alasan_penting' ? 'selected' : ''); ?>>Cuti
                            Alasan Penting</option>
                    </select>
                    <?php $__errorArgs = ['jenis_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tanggal Mulai & Selesai -->
                <div class="row align-items-center">
                    <div class="form-group col-6">
                        <label for="tanggal_mulai">Tanggal Mulai<span class="text-danger">*</span></label>
                        <input type="date" class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="tanggal_mulai" name="tanggal_mulai" value="<?php echo e(old('tanggal_mulai')); ?>" required>
                        <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-6">
                        <label for="tanggal_selesai">Tanggal Selesai<span class="text-danger">*</span></label>
                        <input type="date" class="form-control <?php $__errorArgs = ['tanggal_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="tanggal_selesai" name="tanggal_selesai" value="<?php echo e(old('tanggal_selesai')); ?>" required>
                        <?php $__errorArgs = ['tanggal_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Alasan Cuti -->
                <div class="form-group">
                    <label for="alasan_cuti">Alasan Cuti<span class="text-danger">*</span></label>
                    <textarea class="form-control <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alasan_cuti" name="alasan_cuti"
                        rows="3" placeholder="Jelaskan alasan pengajuan cuti" required><?php echo e(old('alasan_cuti')); ?></textarea>
                    <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="form-group">
                    <label for="diajukan_kepada">Diajukan Kepada<span class="text-danger">*</span></label>
                    <select class="form-select <?php $__errorArgs = ['diajukan_kepada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="diajukan_kepada"
                        id="diajukan_kepada" required>
                        <option selected disabled>Pilih Penerima Surat</option>
                        <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jabatan->id); ?>"
                                <?php echo e(old('diajukan_kepada') == $jabatan->id ? 'selected' : ''); ?>>
                                <?php echo e($jabatan->user->name); ?> (<?php echo e($jabatan->nama); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['diajukan_kepada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Lampiran -->
                <div class="form-group">
                    <label for="lampiran_upload">Lampiran</label>
                    <small class="d-block mb-2">File pendukung dapat berupa surat keterangan dokter, dsb.</small>
                    <input type="file" class="form-control <?php $__errorArgs = ['lampiran_upload'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="lampiran_upload" name="lampiran_upload">
                    <?php $__errorArgs = ['lampiran_upload'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tembusan -->
                <div class="form-group">
                    <div class="mt-2">
                        <div class="fw-semibold">Tembusan</div>
                        <hr class="my-1 divider">
                    </div>

                    <div id="tembusan-wrapper">
                        <div class="input-group mb-2">
                            <select class="form-select tembusan-select" name="tembusan[]">
                                <option selected disabled>Pilih Tembusan</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="button" class="btn btn-danger btn-remove d-none">Hapus</button>
                        </div>
                    </div>
                    <button type="button" id="btn-add-tembusan" class="btn btn-outline-secondary">
                        <i class="bi bi-plus-lg"></i>
                        <span class="fw-semibold">Tembusan</span>
                    </button>
                </div>

                <button class="btn btn-primary mt-4">Ajukan</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#btn-add-tembusan').on('click', function() {
            const inputGroup = `
            <div class="input-group mb-2">
                <select class="form-select tembusan-select" name="tembusan[]">
                    <option selected disabled>Pilih User</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="button" class="btn btn-danger btn-remove">Hapus</button>
            </div>
        `;

            $('#tembusan-wrapper').append(inputGroup);
        });

        $('#tembusan-wrapper').on('click', '.btn-remove', function() {
            $(this).closest('.input-group').remove();
        });

        $(".tembusan-select").on("change", function() {
            $(".btn-remove").removeClass("d-none");
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/usulan/suratCuti/create.blade.php ENDPATH**/ ?>