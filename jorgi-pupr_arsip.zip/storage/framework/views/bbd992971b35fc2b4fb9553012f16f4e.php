<?php
    use Carbon\Carbon;
    $userRole = Auth::user()->role;
    // dd($model->ditujukan);
?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('usulan.index')); ?>" class="btn btn-primary mb-3" style="width: max-content">Kembali</a>
    <div class="row justify-content-center mt-4">
        <div class="col-lg-8 col-md-10 col-sm-12">
            <div class="card shadow-sm p-4 rounded">
                <?php if($userRole != 'user'): ?>
                    <div class="d-flex justify-content-end" style="gap: 12px">
                        <?php if(
                            ($userRole === 'admin' && $model->status === 'menunggu') ||
                                ($userRole === 'kepala_dinas' && $model->status === 'disetujui_admin')): ?>
                            <button id="btnTolak" data-id="<?php echo e($model->id); ?>" class="btn btn-outline-danger">
                                <i class="bi bi-x-lg"></i>
                                Tolak
                            </button>
                        <?php endif; ?>
                        <?php if($model->status === 'menunggu'): ?>
                            <a href="<?php echo e(route('suratCuti.setujuiAdmin', $model->id)); ?>" class="btn btn-success">
                                <i class="bi bi-check-lg"></i>
                                Setujui
                            </a>
                        <?php elseif($model->status === 'disetujui_admin' && $userRole === 'kepala_dinas'): ?>
                            <a href="<?php echo e(route('suratCuti.setujui', $model->id)); ?>" class="btn btn-success">
                                <i class="bi bi-check-lg"></i>
                                Setujui
                            </a>
                        <?php endif; ?>
                        <?php if($userRole === 'admin' && ($model->status === 'disetujui_admin' || $model->status === 'disetujui')): ?>
                            <a href="<?php echo e(route('suratCuti.print', $model->id)); ?>" class="btn btn-primary"
                                style="width: max-content" target="_blank">
                                <i class="bi bi-printer-fill"></i>
                                Cetak
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <h4 class="card-title mb-4 text-center">Detail Surat Cuti</h4>
                <div class="row mb-3">
                    <div class="col-4"><strong>Pengaju </strong></div>
                    <div class="col-8">: <?php echo e($model->pengaju?->name); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-4"><strong>Jenis Cuti </strong></div>
                    <div class="col-8">: <?php echo e($model->jenis_cuti); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-4"><strong>Lama Cuti </strong></div>
                    <div class="col-8">: <?php echo e($model->lama_cuti); ?> hari</div>
                </div>
                <div class="row mb-3">
                    <div class="col-4"><strong>Tanggal Mulai </strong></div>
                    <div class="col-8">
                        : <?php echo e(Carbon::parse($model->tanggal_mulai)->locale('id_ID')->isoFormat('D MMMM Y')); ?>

                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-4"><strong>Tanggal Selesai </strong></div>
                    <div class="col-8">
                        : <?php echo e(Carbon::parse($model->tanggal_selesai)->locale('id_ID')->isoFormat('D MMMM Y')); ?>

                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-4"><strong>Alasan Cuti </strong></div>
                    <div class="col-8">: <?php echo e($model->alasan_cuti); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-4"><strong>Diajukan Kepada</strong></div>
                    <div class="col-8">: <?php echo e($model->ditujukan?->user?->name); ?> (<?php echo e($model->ditujukan?->nama); ?>)</div>
                </div>
                <div class="row mb-3">
                    <div class="col-4">
                        <div>
                            <strong>Status </strong>
                        </div>
                        <?php if($model->status === 'ditolak'): ?>
                            <div class="text-danger">
                                <strong>Alasan Ditolak </strong>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-8">:
                        <?php if($model->status === 'menunggu'): ?>
                            <span class="badge bg-warning">Menunggu</span>
                        <?php elseif($model->status === 'ditolak'): ?>
                            <span class="badge bg-danger">Ditolak</span>
                        <?php elseif($model->status === 'disetujui_admin'): ?>
                            <span class="badge bg-primary">Disetujui Admin</span>
                        <?php elseif($model->status === 'disetujui'): ?>
                            <span class="badge bg-success">Cuti Disetujui</span>
                        <?php endif; ?>
                        <?php if($model->status === 'ditolak'): ?>
                            <div class="text-danger">
                                <span class="text-black">:</span> <?php echo e($model->alasan_ditolak); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-1">
                    <div class="col-md-6">
                        <div><strong>File Lampiran </strong></div>
                        <?php if($model->lampiran): ?>
                            <a href="<?php echo e(asset($model->lampiran)); ?>" class="btn btn-primary btn-sm" target="_blank">
                                Lihat File
                            </a>
                        <?php else: ?>
                            <span>Tidak ada lampiran.</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3 mt-3">
                    <div class="col-4"><strong>Tembusan </strong></div>
                    <?php if($model->tembusan && count($model->tembusan) > 0): ?>
                        <ol class="ms-4">
                            <?php $__currentLoopData = $model->tembusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tembusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($tembusan->user->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $("#btnTolak").click(function() {
            let id = $(this).data("id");
            Swal.fire({
                title: 'Tolak Pengajuan Cuti',
                text: "Masukkan alasan penolakan:",
                input: 'textarea',
                inputPlaceholder: "Tulis alasan penolakan di sini...",
                inputAttributes: {
                    'aria-label': 'Tulis alasan penolakan'
                },
                showCancelButton: true,
                confirmButtonText: 'Tolak',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                inputValidator: (value) => {
                    if (!value) {
                        return 'Anda harus mengisi alasan penolakan!';
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    let alasan = encodeURIComponent(result.value);
                    window.location.href = `/usulan/surat-cuti/${id}/tolak?alasan_ditolak=${alasan}`;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/usulan/suratCuti/show.blade.php ENDPATH**/ ?>