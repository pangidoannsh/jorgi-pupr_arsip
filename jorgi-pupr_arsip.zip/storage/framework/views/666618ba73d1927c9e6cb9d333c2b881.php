
<?php
    $tembusan = $model->tembusan;
    use Carbon\Carbon;
?>
<?php $__env->startSection('content'); ?>
    <style>
        .ttd {
            margin-top: 24px;
            padding-left: 64px;
        }
    </style>
    <div>Dengan Hormat,</div>
    <div style="margin-top: 12px">Bersama ini kami sampaikan bahwa:</div>
    <table>
        <tr>
            <td style="width: 90px">Nama</td>
            <td>: <?php echo e($model->pengaju->name); ?></td>
        </tr>
        <tr>
            <td style="width: 90px">NIP</td>
            <td>: <?php echo e($model->pengaju->nip); ?></td>
        </tr>
        <tr>
            <td style="width: 90px">Jabatan</td>
            <td>: <?php echo e($model->pengaju->nip); ?></td>
        </tr>
        <tr>
            <td style="width: 90px">Unit Kerja</td>
            <td>: <?php echo e($model->pengaju->unit->nama); ?></td>
        </tr>
    </table>
    <div style="margin-top: 8px">
        Dengan ini mengajukan permohonan izin Cuti selama
        <?php echo e($model->lama_cuti); ?> hari, mulai dari
        <?php echo e(Carbon::parse($model->tanggal_mulai)->locale('id_ID')->isoFormat('D MMMM Y')); ?>

        sampai dengan
        <?php echo e(Carbon::parse($model->tanggal_mulai)->locale('id_ID')->isoFormat('D MMMM Y')); ?>. Permohonan izin ini
        diajukan
        untuk <?php echo e($model->alasan_cuti); ?>.
    </div>
    <div style="margin-top: 8px">
        Atas perhatian dann kebijaksanaan yang diberikan, saya ucapkan terima kasih.
    </div>
    <table style="width: 100%">
        <tr>
            <td style="width: 100%"></td>
            <td style="width: 100%"></td>
            <td style="width: 100%">
                <div class="ttd">
                    <div>Hormat kami,</div>
                    <div><?php echo e($model->pengaju->name); ?></div>
                    <div><?php echo e($model->pengaju->jabatan); ?></div>
                    <div style="height: 64px">
                        <img src="<?php echo e('data:image/png;base64,' . base64_encode(file_get_contents(public_path($model->pengaju->ttd)))); ?>"
                            style="height: 100%">
                    </div>
                    <div><?php echo e($model->pengaju->name); ?></div>
                    <div><?php echo e($model->pengaju->nip); ?></div>
                </div>
            </td>
        </tr>
    </table>
    <table style="width: 100%">
        <tr>
            <td style="width: 100%">
                <?php echo $__env->make('pdf.tembusan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </td>
            <td style="width: 100%">
                <div style="float: right">
                    <img src="data:img/png;base64, <?php echo $qrCode; ?>">
                </div>
            </td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/pdf/suratCuti.blade.php ENDPATH**/ ?>