<div class="btn-group">
    <a href="<?php echo e(route('unit.edit', $item)); ?>" class="btn btn-sm btn-warning">
        <i class="bi bi-pencil"></i>
    </a>
    <form action="<?php echo e(route('unit.destroy', $item->id)); ?>" method="POST" class="formDelete">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-sm btn-danger" style="border-radius: 0 .25rem .25rem 0">
            <i class="bi bi-trash"></i>
        </button>
    </form>
</div>
<?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/unit/action.blade.php ENDPATH**/ ?>