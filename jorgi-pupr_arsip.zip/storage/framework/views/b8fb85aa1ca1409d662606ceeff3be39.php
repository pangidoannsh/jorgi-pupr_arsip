

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body pt-3">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('usulan') ? 'active fw-bold' : ''); ?>" aria-current="page"
                        href="<?php echo e(route('usulan.riwayat')); ?>">Usulan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('riwayat-usulan') ? 'active fw-bold' : ''); ?>" aria-current="page"
                        href="<?php echo e(route('usulan.riwayat')); ?>">Riwayat</a>
                </li>
            </ul>
            <div class="mt-3 mb-2">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" id="dropdownUsulan" data-bs-toggle="dropdown"
                        aria-expanded="false" style="width: max-content">
                        <i class="bi bi-plus"></i> Usulan
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownUsulan">
                        <a class="dropdown-item" href="<?php echo e(route('suratCuti.create')); ?>">Surat Cuti</a>
                        <a class="dropdown-item" href="#">Lainnya</a>
                    </div>
                </div>
            </div>
            <!-- Table with hoverable rows -->
            <table class="table table-hover table-stripped" id="dataTable">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Jenis Usulan</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Keterangan</th>
                        <th scope="col">Pengaju</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->jenisUsulan); ?></td>
                            <?php switch($item->jenisUsulan):
                                case ('Surat Cuti'): ?>
                                    <td>
                                        Pengajuan Cuti - <?php echo e($item->jenis_cuti); ?>

                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span>Tanggal Mulai: <?php echo e($item->tanggal_mulai); ?></span>
                                            <span>Lama Cuti: <?php echo e($item->lama_cuti); ?></span>
                                            <span>Alasan: <?php echo e($item->alasan_cuti); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php echo e($item->pengaju?->name); ?>

                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('suratCuti.show', $item->id)); ?>" class="btn btn-sm btn-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </div>
                                    </td>
                                <?php break; ?>

                                <?php default: ?>
                                    undefined
                            <?php endswitch; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- End Table with hoverable rows -->

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).on("submit", ".formDelete", function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Arsip ini akan dihapus secara permanen!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    e.currentTarget.submit()
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/usulan/index.blade.php ENDPATH**/ ?>