<?php if(isset($tembusan)): ?>
    <div>
        <div>Tembusan kepada Yth,</div>
        <ol style="margin-left: -20px">
            <?php
                // Ambil jumlah tembusan
                $tembusanCount = count($tembusan ?? []);
                // Hitung kekurangan jika tembusan kurang dari 4
                $emptyCount = max(0, 4 - $tembusanCount);
            ?>

            <?php $__currentLoopData = $tembusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($surat->user?->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php for($i = 0; $i < $emptyCount; $i++): ?>
                <li>&nbsp;</li>
            <?php endfor; ?>
        </ol>
    </div>
<?php endif; ?>
<?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/pdf/tembusan.blade.php ENDPATH**/ ?>