<div class="btn-group">
    <a href="<?php echo e(route('report.edit', $item)); ?>" class="btn btn-sm btn-primary">
        <i class="bi bi-pencil"></i>
    </a>
    <form action="<?php echo e(route('report.destroy', $item->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-sm btn-danger" style="border-radius: 0 .25rem .25rem 0">
            <i class="bi bi-trash"></i>
        </button>
    </form>
</div>
<?php /**PATH D:\PROJECT\jorgi-pupr_arsip\resources\views/partials/action-button.blade.php ENDPATH**/ ?>