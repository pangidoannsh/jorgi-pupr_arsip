<a href="{{ $item->link }}" target="_blank">{{ $item->name }}</a>
