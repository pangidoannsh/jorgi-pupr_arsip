<?php

return [
    App\Providers\AppServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
    RealRashid\SweetAlert\SweetAlertServiceProvider::class,
    Barryvdh\DomPDF\ServiceProvider::class
];
