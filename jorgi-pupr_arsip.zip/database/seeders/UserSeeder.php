<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            "nip" => "admin123",
            "jabatan" => "KEPALA SUB BAGIAN UMUM",
            "unit_id" => "1",
            "name" => "admin",
            "role" => "admin",
            "ttd" => "uploads/user/ttd_dummy.png",
            "password" => bcrypt("1")
        ]);

        User::create([
            "nip" => "ux123",
            "jabatan" => "Test Jabatan",
            "unit_id" => "1",
            "name" => "Qosim",
            "role" => "user",
            "ttd" => "uploads/user/ttd_dummy.png",
            "password" => bcrypt("1")
        ]);
        User::create([
            "nip" => "dp123",
            "jabatan" => "Test Jabatan",
            "unit_id" => "1",
            "name" => "Dewangga",
            "role" => "user",
            "ttd" => "uploads/user/ttd_dummy.png",
            "password" => bcrypt("1")
        ]);

        User::create([
            "nip" => "kepaladinas123",
            "jabatan" => "Kepala Dinas",
            "unit_id" => "1",
            "name" => "Burhanudin",
            "role" => "kepala_dinas",
            "ttd" => "uploads/user/ttd_dummy.png",
            "password" => bcrypt("1")
        ]);
    }
}
